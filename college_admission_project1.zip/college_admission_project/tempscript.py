import pandas as pd

df = pd.read_csv("ts-eamcet-2023-cut-off.csv")
print(df.columns.tolist())
