from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__)

# Load and clean dataset
df = pd.read_csv("ts-eamcet-2023-cut-off.csv")
df.columns = df.columns.str.strip().str.lower().str.replace("\n", "_").str.replace(" ", "_")

# ✅ Map district codes to full names
district_mapping = {
    'HYD': 'Hyderabad',
    'WGL': 'Warangal',
    'KMR': 'Karimnagar',
    'NZB': 'Nizamabad',
    'KHM': 'Khammam',
    'MDL': 'Medchal',
    'MBN': 'Mahabubnagar',
    'RR': 'Ranga Reddy',
    'PDL': 'Peddapalli',
    'SRC': 'Sircilla',
    'KGM': 'Kagaznagar',
    'NLG': 'Nalgonda',
    'JGN': 'Jangaon',
    'JTL': 'Jagtial',
    'MED': 'Medak',
    'YBG': 'Yadadri Bhuvanagiri',
    'HNK': 'Hanumakonda',
    'SRD': 'Suryapet',
    'SRP': 'Sangareddy',
    'WNP': 'Wanaparthy',
    'SDP': 'Siddipet'
}

df['dist'] = df['dist'].map(district_mapping)
districts = sorted(df['dist'].dropna().unique())

# Cutoff columns
available_cutoff_cols = df.columns[df.columns.str.contains('_boys|_girls')].tolist()

def get_cutoff_column(caste, gender):
    caste = caste.lower().replace("-", "_")
    gender = gender.lower()
    suffix = 'boys' if gender == 'male' else 'girls'
    return f"{caste}_{suffix}"

# Main recommendation logic
def recommend_colleges(rank, caste, gender, branch, num_colleges, selected_districts=None):
    col_name = get_cutoff_column(caste, gender)
    if col_name not in df.columns:
        return f"Category/Gender combination not found: {col_name}"

    df_filtered = df[
        (df['branch'] == branch.upper()) &
        (pd.to_numeric(df[col_name], errors='coerce').notna())
    ].copy()

    if selected_districts:
        df_filtered = df_filtered[df_filtered['dist'].isin(selected_districts)]

    df_filtered[col_name] = pd.to_numeric(df_filtered[col_name], errors='coerce')
    df_eligible = df_filtered[df_filtered[col_name] >= rank]
    df_eligible = df_eligible.sort_values(by=col_name).head(num_colleges)

    if df_eligible.empty:
        return "⚠️ No eligible colleges found for your inputs."

    return df_eligible[['institute_name', 'place', 'dist', 'branch', col_name]].rename(columns={
        'institute_name': 'College Name',
        'place': 'Location',
        'dist': 'District',
        'branch': 'Branch',
        col_name: 'Closing Rank'
    })

@app.route('/')
def index():
    return render_template("index.html", districts=districts)

@app.route('/result', methods=["POST"])
def result():
    email = request.form['email']
    name = request.form['name']
    rank = int(request.form['rank'])
    caste = request.form['caste']
    gender = request.form['gender']
    branch = request.form['branch']
    num_colleges = int(request.form['num_colleges'])
    selected_districts = request.form.getlist('districts')  # ✅ Multi-select

    result = recommend_colleges(rank, caste, gender, branch, num_colleges, selected_districts)

    if isinstance(result, str):
        return render_template("result.html", name=name, message=result)

    return render_template("result.html", name=name, tables=[result.to_html(classes='data', index=False)])

if __name__ == "__main__":
    app.run(debug=True)
